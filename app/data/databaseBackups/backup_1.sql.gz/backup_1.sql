-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: November 27, 2019 at 21:23 PM ( Europe/Berlin )
-- PHP Version: 7.3.9
--
-- ---------------------------------------------------------


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `client`
--
-- ---------------------------------------------------------
CREATE TABLE `client` (
  `client_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) NOT NULL,
  `business_number` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `cell_number` varchar(20) NOT NULL,
  `website` varchar(50) DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--
INSERT INTO `client` (`client_id`, `company_name`, `business_number`, `first_name`, `last_name`, `phone_number`, `cell_number`, `website`, `status`) VALUES
(3, 'Lexagene', '12345689 RT 0001', 'jack', 'jim', '416-967-1111', '647-999-3821', 'www.google.com', 'archive'),
(4, 'george brown', 123456789, 'billybob', 'vojinovic', 4169028900, '647-884-3344', 'www.jesus.ca', 'archive'),
(5, 'george brown', 77777777777, 'nikola', 'bababooo', 4169028900, '111 111 1111', 'www.blah.org', 'archive'),
(6, 'george brown', 'george brown', 'nikola', 'vojinovic', 4169028900, 4169028900, 'www.jesus.com', 'archive'),
(7, 'george brown', 'george brown', 'nikola', 'vojinovic', 4169028900, 4169028900, 'blah.org', 'archive'),
(8, 'asihfsaodifh', 11111111111111111, 'bendi', 'poper', '444 444 8888', '999 888 7777', 'www.jesus.com', 'active');



-- ---------------------------------------------------------
--
-- Table structure for table : `clientnotifications`
--
-- ---------------------------------------------------------
CREATE TABLE `clientnotifications` (
  `client_event_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) NOT NULL,
  `notification_id` int(10) NOT NULL,
  `start_date` varchar(50) NOT NULL,
  `frequency` varchar(50) NOT NULL,
  `client_event_status` varchar(50) NOT NULL,
  PRIMARY KEY (`client_event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientnotifications`
--
INSERT INTO `clientnotifications` (`client_event_id`, `client_id`, `notification_id`, `start_date`, `frequency`, `client_event_status`) VALUES
(1, 4, 1, '2019/11/23', 'every 30 days', 'archive'),
(2, 3, 1, '2019/11/23', 'every 30 days', 'archive'),
(3, 4, 5, '2019/10/25', 'every 20 days', 'active'),
(4, 4, 1, '2019/10/25', 'every 20 days', 'active'),
(5, 5, 1, '2019/10/25', 'every 20 days', 'active');



-- ---------------------------------------------------------
--
-- Table structure for table : `logs`
--
-- ---------------------------------------------------------
CREATE TABLE `logs` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `chosen_module` varchar(50) NOT NULL,
  `action_taken` varchar(50) NOT NULL,
  `date_time` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=342 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--
INSERT INTO `logs` (`log_id`, `username`, `chosen_module`, `action_taken`, `date_time`, `ip_address`) VALUES
(149, 'w9181089', 'clients', 'view', '2019-11-26 04:37:11am', '::1'),
(150, 'w9181089', 'users', 'add', '2019-11-26 04:37:19am', '::1'),
(151, 'w9181089', 'clients', 'view', '2019-11-26 04:37:22am', '::1'),
(152, 'w9181089', 'users', 'view', '2019-11-26 04:37:39am', '::1'),
(153, 'w9181089', 'clients', 'view', '2019-11-26 04:37:46am', '::1'),
(154, 'w9181089', 'clients', 'view', '2019-11-26 04:39:02am', '::1'),
(155, 'w9181089', 'clients', 'view', '2019-11-26 04:39:50am', '::1'),
(156, 'w9181089', 'clients', 'view', '2019-11-26 04:39:53am', '::1'),
(157, 'w9181089', 'clients', 'view', '2019-11-26 04:40:59am', '::1'),
(158, 'w9181089', 'clients', 'view', '2019-11-26 04:41:01am', '::1'),
(159, 'w9181089', 'clients', 'view', '2019-11-26 04:41:01am', '::1'),
(160, 'w9181089', 'clients', 'view', '2019-11-26 04:41:02am', '::1'),
(161, 'w9181089', 'users', 'view', '2019-11-26 04:42:05am', '::1'),
(162, 'w9181089', 'users', 'add', '2019-11-26 05:16:08am', '::1'),
(163, 'w9181089', 'users', 'view', '2019-11-26 05:17:41am', '::1'),
(164, 'godlyJeff', 'users', 'view', '2019-11-26 08:32:44pm', '::1'),
(165, 'godlyJeff', 'clients', 'view', '2019-11-26 08:32:52pm', '::1'),
(166, 'godlyJeff', 'clients', 'view', '2019-11-26 08:38:11pm', '::1'),
(167, 'godlyJeff', 'clients', 'add', '2019-11-26 08:41:44pm', '::1'),
(168, 'godlyJeff', 'notifications', 'view', '2019-11-26 08:41:47pm', '::1'),
(169, 'godlyJeff', 'client events', 'view', '2019-11-26 08:41:50pm', '::1'),
(170, 'godlyJeff', 'users', 'view', '2019-11-26 08:41:54pm', '::1'),
(171, 'godlyJeff', 'users', 'add', '2019-11-26 08:41:58pm', '::1'),
(172, 'godlyJeff', 'clients', 'view', '2019-11-26 10:11:11pm', '::1'),
(173, 'godlyJeff', 'clients', 'add', '2019-11-26 10:31:41pm', '::1'),
(174, 'godlyJeff', 'clients', 'add', '2019-11-26 10:31:45pm', '::1'),
(175, 'godlyJeff', 'clients', 'view', '2019-11-26 10:32:17pm', '::1'),
(176, 'godlyJeff', 'clients', 'view', '2019-11-26 10:32:29pm', '::1'),
(177, 'godlyJeff', 'clients', 'view', '2019-11-26 10:32:42pm', '::1'),
(178, 'w9181089', 'clients', 'view', '2019-11-27 01:49:39am', '::1'),
(179, 'godlyJeff', 'users', 'view', '2019-11-27 02:25:53am', '::1'),
(180, 'godlyJeff', 'users', 'view', '2019-11-27 02:26:08am', '::1'),
(181, 'godlyJeff', 'users', 'view', '2019-11-27 02:26:11am', '::1'),
(182, 'godlyJeff', 'users', 'view', '2019-11-27 02:26:12am', '::1'),
(183, 'godlyJeff', 'users', 'view', '2019-11-27 02:26:12am', '::1'),
(184, 'godlyJeff', 'users', 'view', '2019-11-27 02:26:23am', '::1'),
(185, 'godlyJeff', 'users', 'view', '2019-11-27 02:27:45am', '::1'),
(186, 'godlyJeff', 'users', 'view', '2019-11-27 02:28:02am', '::1'),
(187, 'godlyJeff', 'users', 'view', '2019-11-27 02:29:49am', '::1'),
(188, 'godlyJeff', 'clients', 'view', '2019-11-27 02:30:05am', '::1'),
(189, 'godlyJeff', 'clients', 'view', '2019-11-27 02:32:05am', '::1'),
(190, 'godlyJeff', 'clients', 'view', '2019-11-27 02:33:03am', '::1'),
(191, 'godlyJeff', 'clients', 'view', '2019-11-27 02:33:50am', '::1'),
(192, 'godlyJeff', 'clients', 'view', '2019-11-27 02:34:13am', '::1'),
(193, 'godlyJeff', 'clients', 'view', '2019-11-27 02:35:09am', '::1'),
(194, 'godlyJeff', 'clients', 'view', '2019-11-27 02:35:30am', '::1'),
(195, 'godlyJeff', 'clients', 'view', '2019-11-27 02:36:22am', '::1'),
(196, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:10am', '::1'),
(197, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:27am', '::1'),
(198, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:30am', '::1'),
(199, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:31am', '::1'),
(200, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:32am', '::1'),
(201, 'godlyJeff', 'clients', 'view', '2019-11-27 02:37:50am', '::1'),
(202, 'godlyJeff', 'clients', 'add', '2019-11-27 02:40:14am', '::1'),
(203, 'godlyJeff', 'clients', 'view', '2019-11-27 02:41:49am', '::1'),
(204, 'godlyJeff', 'clients', 'view', '2019-11-27 02:44:02am', '::1'),
(205, 'godlyJeff', 'clients', 'view', '2019-11-27 02:57:32am', '::1'),
(206, 'godlyJeff', 'clients', 'add', '2019-11-27 02:59:06am', '::1'),
(207, 'godlyJeff', 'clients', 'view', '2019-11-27 03:00:13am', '::1'),
(208, 'godlyJeff', 'client events', 'view', '2019-11-27 03:01:05am', '::1'),
(209, 'godlyJeff', 'clients', 'view', '2019-11-27 03:18:01am', '::1'),
(210, 'godlyJeff', 'notifications', 'view', '2019-11-27 03:18:14am', '::1'),
(211, 'godlyJeff', 'clients', 'view', '2019-11-27 03:22:46am', '::1'),
(212, 'godlyJeff', 'clients', 'view', '2019-11-27 03:23:08am', '::1'),
(213, 'godlyJeff', 'notifications', 'view', '2019-11-27 03:23:16am', '::1'),
(214, 'godlyJeff', 'notifications', 'view', '2019-11-27 03:24:10am', '::1'),
(215, 'godlyJeff', 'users', 'view', '2019-11-27 03:24:55am', '::1'),
(216, 'godlyJeff', 'users', 'view', '2019-11-27 03:25:03am', '::1'),
(217, 'godlyJeff', 'users', 'view', '2019-11-27 03:25:05am', '::1'),
(218, 'godlyJeff', 'clients', 'view', '2019-11-27 03:25:32am', '::1'),
(219, 'godlyJeff', 'clients', 'add', '2019-11-27 03:34:49am', '::1'),
(220, 'godlyJeff', 'clients', 'add', '2019-11-27 03:36:26am', '::1'),
(221, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:04am', '::1'),
(222, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:05am', '::1'),
(223, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:06am', '::1'),
(224, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:25am', '::1'),
(225, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:25am', '::1'),
(226, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:27am', '::1'),
(227, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:28am', '::1'),
(228, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:48am', '::1'),
(229, 'godlyJeff', 'clients', 'add', '2019-11-27 03:37:49am', '::1'),
(230, 'godlyJeff', 'clients', 'add', '2019-11-27 03:38:06am', '::1'),
(231, 'godlyJeff', 'clients', 'view', '2019-11-27 03:39:32am', '::1'),
(232, 'godlyJeff', 'clients', 'view', '2019-11-27 03:53:32am', '::1'),
(233, 'godlyJeff', 'clients', 'add', '2019-11-27 03:57:35am', '::1'),
(234, 'godlyJeff', 'clients', 'add', '2019-11-27 04:01:50am', '::1'),
(235, 'godlyJeff', 'clients', 'add', '2019-11-27 04:01:52am', '::1'),
(236, 'godlyJeff', 'clients', 'add', '2019-11-27 04:02:42am', '::1'),
(237, 'godlyJeff', 'clients', 'add', '2019-11-27 04:03:06am', '::1'),
(238, 'godlyJeff', 'clients', 'add', '2019-11-27 04:03:37am', '::1'),
(239, 'godlyJeff', 'clients', 'add', '2019-11-27 04:03:58am', '::1'),
(240, 'godlyJeff', 'clients', 'add', '2019-11-27 04:04:09am', '::1'),
(241, 'godlyJeff', 'clients', 'add', '2019-11-27 04:04:30am', '::1'),
(242, 'godlyJeff', 'clients', 'add', '2019-11-27 04:05:20am', '::1'),
(243, 'godlyJeff', 'clients', 'add', '2019-11-27 04:05:26am', '::1'),
(244, 'godlyJeff', 'clients', 'add', '2019-11-27 04:05:47am', '::1'),
(245, 'godlyJeff', 'clients', 'add', '2019-11-27 04:06:14am', '::1'),
(246, 'godlyJeff', 'clients', 'add', '2019-11-27 04:06:54am', '::1'),
(247, 'godlyJeff', 'clients', 'add', '2019-11-27 04:07:32am', '::1'),
(248, 'godlyJeff', 'clients', 'add', '2019-11-27 04:08:09am', '::1'),
(249, 'godlyJeff', 'clients', 'add', '2019-11-27 04:08:23am', '::1'),
(250, 'godlyJeff', 'clients', 'view', '2019-11-27 04:08:26am', '::1'),
(251, 'godlyJeff', 'clients', 'add', '2019-11-27 04:09:31am', '::1'),
(252, 'godlyJeff', 'clients', 'add', '2019-11-27 04:12:21am', '::1'),
(253, 'godlyJeff', 'clients', 'add', '2019-11-27 04:12:49am', '::1'),
(254, 'godlyJeff', 'clients', 'add', '2019-11-27 04:12:57am', '::1'),
(255, 'godlyJeff', 'clients', 'add', '2019-11-27 04:13:08am', '::1'),
(256, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:35am', '::1'),
(257, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:36am', '::1'),
(258, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:37am', '::1'),
(259, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:38am', '::1'),
(260, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:42am', '::1'),
(261, 'godlyJeff', 'clients', 'add', '2019-11-27 04:14:58am', '::1'),
(262, 'godlyJeff', 'clients', 'view', '2019-11-27 04:38:18am', '::1'),
(263, 'godlyJeff', 'clients', 'add', '2019-11-27 04:38:26am', '::1'),
(264, 'godlyJeff', 'users', 'add', '2019-11-27 04:39:42am', '::1'),
(265, 'godlyJeff', 'notifications', 'view', '2019-11-27 04:39:51am', '::1'),
(266, 'godlyJeff', 'notifications', 'update', '2019-11-27 04:40:05am', '::1'),
(267, 'godlyJeff', 'clients', 'add', '2019-11-27 04:40:30am', '::1'),
(268, 'godlyJeff', 'clients', 'add', '2019-11-27 04:41:12am', '::1'),
(269, 'godlyJeff', 'clients', 'add', '2019-11-27 04:41:13am', '::1'),
(270, 'godlyJeff', 'clients', 'add', '2019-11-27 04:41:14am', '::1'),
(271, 'godlyJeff', 'clients', 'add', '2019-11-27 04:41:15am', '::1'),
(272, 'godlyJeff', 'clients', 'add', '2019-11-27 04:41:24am', '::1'),
(273, 'godlyJeff', 'clients', 'view', '2019-11-27 04:50:31am', '::1'),
(274, 'godlyJeff', 'clients', 'add', '2019-11-27 04:53:07am', '::1'),
(275, 'godlyJeff', 'clients', 'add', '2019-11-27 04:53:21am', '::1'),
(276, 'godlyJeff', 'clients', 'add', '2019-11-27 04:54:26am', '::1'),
(277, 'godlyJeff', 'clients', 'add', '2019-11-27 04:54:36am', '::1'),
(278, 'godlyJeff', 'clients', 'add', '2019-11-27 04:55:17am', '::1'),
(279, 'godlyJeff', 'clients', 'add', '2019-11-27 04:55:20am', '::1'),
(280, 'godlyJeff', 'clients', 'update', '2019-11-27 04:55:40am', '::1'),
(281, 'godlyJeff', 'clients', 'update', '2019-11-27 04:56:46am', '::1'),
(282, 'godlyJeff', 'clients', 'update', '2019-11-27 04:57:07am', '::1'),
(283, 'godlyJeff', 'clients', 'update', '2019-11-27 04:57:22am', '::1'),
(284, 'godlyJeff', 'clients', 'update', '2019-11-27 04:57:54am', '::1'),
(285, 'godlyJeff', 'clients', 'update', '2019-11-27 05:00:59am', '::1'),
(286, 'w9181089', 'clients', 'view', '2019-11-27 05:03:15am', '::1'),
(287, 'w9181089', 'clients', 'view', '2019-11-27 05:03:48am', '::1'),
(288, 'w9181089', 'clients', 'update', '2019-11-27 05:03:50am', '::1'),
(289, 'w9181089', 'clients', 'add', '2019-11-27 05:03:55am', '::1'),
(290, 'w9181089', 'clients', 'activate', '2019-11-27 05:03:59am', '::1'),
(291, 'w9181089', 'clients', 'activate', '2019-11-27 05:05:13am', '::1'),
(292, 'w9181089', 'clients', 'activate', '2019-11-27 05:05:31am', '::1'),
(293, 'w9181089', 'clients', 'activate', '2019-11-27 05:05:44am', '::1'),
(294, 'w9181089', 'clients', 'activate', '2019-11-27 05:05:54am', '::1'),
(295, 'w9181089', 'clients', 'activate', '2019-11-27 05:06:04am', '::1'),
(296, 'w9181089', 'clients', 'archive', '2019-11-27 05:07:18am', '::1'),
(297, 'w9181089', 'clients', 'view', '2019-11-27 05:07:57am', '::1'),
(298, 'w9181089', 'clients', 'view', '2019-11-27 05:09:49am', '::1'),
(299, 'w9181089', 'clients', 'view', '2019-11-27 05:10:11am', '::1'),
(300, 'w9181089', 'clients', 'view', '2019-11-27 05:10:19am', '::1'),
(301, 'w9181089', 'clients', 'view', '2019-11-27 05:14:00am', '::1'),
(302, 'w9181089', 'clients', 'add', '2019-11-27 05:14:05am', '::1'),
(303, 'w9181089', 'notifications', 'view', '2019-11-27 05:14:16am', '::1'),
(304, 'w9181089', 'notifications', 'add', '2019-11-27 05:14:22am', '::1'),
(305, 'w9181089', 'clients', 'update', '2019-11-27 05:16:58am', '::1'),
(306, 'w9181089', 'notifications', 'update', '2019-11-27 05:18:42am', '::1'),
(307, 'w9181089', 'notifications', 'update', '2019-11-27 05:22:44am', '::1'),
(308, 'w9181089', 'notifications', 'update', '2019-11-27 05:22:57am', '::1'),
(309, 'w9181089', 'notifications', 'disable', '2019-11-27 05:24:24am', '::1'),
(310, 'w9181089', 'notifications', 'update', '2019-11-27 05:25:25am', '::1'),
(311, 'w9181089', 'notifications', 'update', '2019-11-27 05:26:11am', '::1'),
(312, 'w9181089', 'notifications', 'update', '2019-11-27 05:26:40am', '::1'),
(313, 'w9181089', 'notifications', 'update', '2019-11-27 05:26:58am', '::1'),
(314, 'w9181089', 'notifications', 'update', '2019-11-27 05:27:26am', '::1'),
(315, 'w9181089', 'notifications', 'update', '2019-11-27 05:30:31am', '::1'),
(316, 'w9181089', 'notifications', 'update', '2019-11-27 05:30:33am', '::1'),
(317, 'w9181089', 'notifications', 'add', '2019-11-27 05:30:37am', '::1'),
(318, 'w9181089', 'notifications', 'add', '2019-11-27 05:30:48am', '::1'),
(319, 'w9181089', 'users', 'view', '2019-11-27 05:30:59am', '::1'),
(320, 'w9181089', 'clients', 'view', '2019-11-27 05:31:17am', '::1'),
(321, 'w9181089', 'clients', 'view', '2019-11-27 05:39:22am', '::1'),
(322, 'w9181089', 'clients', 'view', '2019-11-27 04:18:31pm', '::1'),
(323, 'w9181089', 'clients', 'update', '2019-11-27 04:18:41pm', '::1'),
(324, 'w9181089', 'client events', 'view', '2019-11-27 04:18:47pm', '::1'),
(325, 'w9181089', 'clients', 'view', '2019-11-27 04:19:03pm', '::1'),
(326, 'w9181089', 'clients', 'view', '2019-11-27 04:19:07pm', '::1'),
(327, 'w9181089', 'clients', 'view', '2019-11-27 04:32:18pm', '::1'),
(328, 'w9181089', 'users', 'add', '2019-11-27 05:09:27pm', '::1'),
(329, 'w9181089', 'users', 'activate', '2019-11-27 05:15:02pm', '::1'),
(330, 'w9181089', 'users', 'activate', '2019-11-27 05:15:25pm', '::1'),
(331, 'w9181089', 'users', 'suspend', '2019-11-27 05:16:48pm', '::1'),
(332, 'w9181089', 'users', 'activate', '2019-11-27 05:16:54pm', '::1'),
(333, 'w9181089', 'users', 'suspend', '2019-11-27 05:17:56pm', '::1'),
(334, 'w9181089', 'users', 'view', '2019-11-27 05:17:57pm', '::1'),
(335, 'w9181089', 'users', 'activate', '2019-11-27 05:18:00pm', '::1'),
(336, 'w9181089', 'users', 'view', '2019-11-27 05:18:19pm', '::1'),
(337, 'w9181089', 'users', 'activate', '2019-11-27 05:18:30pm', '::1'),
(338, 'w9181089', 'users', 'view', '2019-11-27 05:19:05pm', '::1'),
(339, 'w9181089', 'users', 'activate', '2019-11-27 05:20:06pm', '::1'),
(340, 'w9181089', 'users', 'view', '2019-11-27 05:20:07pm', '::1'),
(341, 'w9181089', 'users', 'add', '2019-11-27 05:23:22pm', '::1');



-- ---------------------------------------------------------
--
-- Table structure for table : `notifications`
--
-- ---------------------------------------------------------
CREATE TABLE `notifications` (
  `notification_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notification_name` varchar(50) NOT NULL,
  `notification_type` varchar(50) NOT NULL,
  `notification_status` varchar(50) NOT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--
INSERT INTO `notifications` (`notification_id`, `notification_name`, `notification_type`, `notification_status`) VALUES
(1, 'business tax message', 'email', 'enabled'),
(2, 'individual tax message', 'sms', 'enabled'),
(3, 'group tax message', 'email', 'enabled'),
(4, 'business tax message', 'sms', 'disabled'),
(5, 'corporate tax message', 'email', 'disabled');



-- ---------------------------------------------------------
--
-- Table structure for table : `users`
--
-- ---------------------------------------------------------
CREATE TABLE `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_first_name` varchar(50) NOT NULL,
  `user_last_name` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_cell_number` varchar(50) NOT NULL,
  `user_position` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_status` varchar(50) NOT NULL,
  `user_picture` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`user_id`, `user_first_name`, `user_last_name`, `user_email`, `user_cell_number`, `user_position`, `username`, `password`, `user_status`, `user_picture`) VALUES
(2, 'nikola', 'vojinovic', 'nikola.vojinovic@georgebrown.ca', 4169028900, 'Manager', 'w9181089', 'Vacation2', 'Active', 'Jesuss'),
(3, 'jeff', 'godly', 'jeff.godly@gmail.ca', '416 555 8900', 'Senior Accountant', 'godlyJeff', 'Coconut', 'Active', 'Crab Swimming'),
(4, 'Kurt', 'McKinnon', 'kurtM@hotmail.com', '647 889 1234', 'Junior Accountant ', 'kurtMacAttack', 'jimboJones', 'Suspended', 'Apple Pie '),
(5, 'gurtrude', 'fickle', 'gf@gmail.com', '416 123 4567', 'Chartered Accountant', 'FickleFlame', 'Flame', 'Active', 'A campfire'),
(7, 'john', 'jones', 'goddamn@yahoo.com', '416 777 8888', 'Bookkeeper', 'JohnJones', 'jones', 'Active', 'hello'),
(10, 'billy', 'bob', 'BOB@yahoo.com', '416 123 4567', 'Bookkeeper', 'billyBob', 'billyBob', 'Active', '1574732325_'),
(16, 'Quinn', 'Quek', 'quinn@yahoo.com', '416-111-1111', 'Senior Accountant', 'quackers', 'quackers', 'Suspended', '1574733213_realmario-12fstdk-300x300.jpg'),
(17, 'nikola', 'vojinovic', 'nikola.vojinovic@georgebrown.ca', 4169028900, 'Chartered Accountant', 'f9181089', 'dsafsaf', 'Suspended', '1574737234_realmario-12fstdk-300x300.jpg');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;